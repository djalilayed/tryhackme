# /opt/ctf/crc_challenge/gateway_proto.py

POLY        = 0x04C11DB7
INIT        = 0xFFFFFFFF
XOR_OUT     = 0xFFFFFFFF
REFLECT_IN  = True
REFLECT_OUT = True
BLOCK_SIZE  = 16

def reflect8(b):
    r = 0
    for i in range(8):
        if b & (1 << i):
            r |= 1 << (7 - i)
    return r

def reflect32(x):
    r = 0
    for i in range(32):
        if x & (1 << i):
            r |= 1 << (31 - i)
    return r

def crc32(data: bytes) -> int:
    crc = INIT
    for b in data:
        if REFLECT_IN:
            b = reflect8(b)
        crc ^= (b << 24)
        for _ in range(8):
            if crc & 0x80000000:
                crc = (crc << 1) ^ POLY
            else:
                crc <<= 1
            crc &= 0xFFFFFFFF
    if REFLECT_OUT:
        crc = reflect32(crc)
    return crc ^ XOR_OUT
